# Contract-Driven Development: Student API

This example contains:
- `contract/openapi.yaml`: the agreed API contract.
- `provider-service`: Spring Boot REST API that provides student details.
- `consumer-service`: Spring Boot application that calls the provider.

## Requirements
- Java 17+
- Maven 3.6+

## Run the provider
Open a terminal in `provider-service` and run:
```bash
mvn spring-boot:run
```
Provider starts at `http://localhost:8080`.

Test:
```bash
curl -i http://localhost:8080/student
```
Expected status: `200 OK`.

## Run the consumer
Open another terminal in `consumer-service` and run:
```bash
mvn spring-boot:run
```
Consumer starts at `http://localhost:8081`.

Call:
```bash
curl -i http://localhost:8081/get-student
```
The consumer calls the provider at `http://localhost:8080/student` and returns the provider's response.

## Contract
The OpenAPI contract is in `contract/openapi.yaml`. Both services use the agreed endpoint and JSON fields:
`id`, `name`, and `course`.

If the provider changes these fields or the response structure, the consumer may need changes too. Update the contract and test both sides before deploying.
