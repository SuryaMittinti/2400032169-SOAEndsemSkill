package com.example.provider.controller;

import com.example.provider.model.Student;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StudentController {

    @GetMapping("/student")
    public ResponseEntity<Student> getStudent() {
        Student student = new Student(101, "Surya", "Java");
        return ResponseEntity.ok(student); // HTTP 200 OK
    }
}
