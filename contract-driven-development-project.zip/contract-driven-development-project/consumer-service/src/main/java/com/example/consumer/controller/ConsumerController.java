package com.example.consumer.controller;

import com.example.consumer.model.Student;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClient;

@RestController
public class ConsumerController {

    private final RestClient restClient = RestClient.create();

    @GetMapping("/get-student")
    public ResponseEntity<Student> getStudentFromProvider() {
        Student student = restClient.get()
                .uri("http://localhost:8080/student")
                .retrieve()
                .body(Student.class);

        return ResponseEntity.ok(student); // HTTP 200 OK from consumer
    }
}
